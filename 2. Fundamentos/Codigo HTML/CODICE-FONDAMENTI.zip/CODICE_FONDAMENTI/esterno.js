function miaFunzione() {
   document.getElementById("demo").innerHTML = "Cambiamo il paragrafo";
}